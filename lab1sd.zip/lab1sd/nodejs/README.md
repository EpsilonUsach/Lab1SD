NodeJS - Tercera clase
==========

Ejemplo de NodeJS conjunto con un módulo Express y Socket.io, el cual levanta una chat con múltiples salas con un estilo CSS usando multicast y broadcast.
